
notification_types = {
    "NONE": None
}

DAYS_OF_THE_YEAR = ["JAN","FEB","MAR","APR","MAY","JUN","JLY","AUG","SEPT","OCT","NOV","DEC"]